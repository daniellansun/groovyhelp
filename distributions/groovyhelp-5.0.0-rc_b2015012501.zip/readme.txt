﻿/****************************************************************

  The GroovyHelp Project (http://code.google.com/p/groovyhelp/)

  Owner:	孙岚(Daniel.Sun)
  Email:	realbluesun@hotmail.com
  Weibo:	http://weibo.com/realbluesun

****************************************************************/

Ⅰ. What is GroovyHelp?

  GroovyHelp is a powerful tool designed for the developers that need to view, search and compare API documentations(Javadoc & Groovydoc). It can help you avoid wasting time in finding API documentations in CHM format and manage all API documentations efficiently. 


Ⅱ. How to use it?

  Basic usage:
  1. Make sure you have installed Java 6+ on your machine.
  2. Add an environment variable named "GROOVYHELP_JAVA_HOME" and specify its value as the location of jre/jdk(e.g. D:\_DEV\Java\jdk1.7.0, /opt/Java/jdk1.7.0).
  3. Run groovyhelp.exe("Run as administrator" under Windows 7+) or groovyhelp(Under Linux and Mac OS X, you should assign execution permission to "groovyhelp" file by executing command "chmod 755 groovyhelp").
  4. Add all sorts of API documentations(e.g. Documentations of Java 1.4+, Apache-Commons, Spring, iBatis, Hibernate and so on, *the API documentations have to be downloaded by yourself*) to GroovyHelp, which will build index for them.
  5. Type keywords to search and view.

  Note: It is strongly recommended to run GroovyHelp on the Oracle JDK/JRE (1.6.0u10+ / 1.7.0u60+) .
  
  Other usages:
  1. To change the skin of the software, put L&F jars into directory lnf and modify groovyhelp.properties(lnf).
  2. To set the http proxy, just modify groovyhelp.properties(http.proxyHost, http.proxyPort, [proxy.username, proxy.password]) and restart GroovyHelp.


Ⅲ. Any tutorial?

  The wiki page(http://code.google.com/p/groovyhelp/w/list) on the GroovyHelp project site contains some articles on how to use GroovyHelp. 


Ⅳ. Source Code?

  GroovyHelp is a free software, but not open source currently. 


Ⅴ. How to contribute?

  If you are interested in helping the project, just send me an e-mail. Any feedback and suggestions are always welcome!



Ⅵ. Appendix

  VirSCAN.org Scanned Report Of groovyhelp.exe(3.4.5 GA):

------------------------- BEGIN ---------------------------------

NOTICE: Results are not 100% accurate and can be reported as a false positive by some scanners when malware is found. Please judge these results by yourself.

VirSCAN.org Scanned Report :
Scanned time   : 2014-10-01 11:47:18
Scanner results: 7% Scanner(s) (3/39) found malware!
File Name      : groovyhelp.exe
File Size      : 60416 byte
File Type      : application/x-dosexec
MD5            : 8146ee33f518b38cf1d9621ad60fe888
SHA1           : 22a309eedaf05f3b933ed5826e8e6a3c212dbcba
Online report  : http://r.virscan.org/report/9a1ed66a4c07008062e483efb8303ae4

Scanner        Engine Ver      Sig Ver           Sig Date    Time   Scan result
ahnlab         9.9.9          9.9.9             2013-05-28     3    Found nothing                 
antivir        1.9.2.0        1.9.159.0         7.11.175.178   14   Found nothing                 
antiy          122826         AVL140921         2014-09-22     5    Found nothing                 
arcavir        1.0            2011              2014-05-30     10   Found nothing                 
asquared       9.0.0.4157     9.0.0.4157        2014-07-30     1    Found nothing                 
avast          140930-0       4.7.4             2014-09-30     28   Found nothing                 
avg            2109/7766      10.0.1405         2014-09-24     1    Found nothing                 
baidu          2.0.1.0        4.1.3.52192       2.0.1.0        4    Found nothing                 
baidusd        1.0            1.0               2014-04-02     1    Found nothing                 
bitdefender    7.57047        7.90123           2014-10-01     6    Found nothing                 
clamav         19452          0.97.5            2014-09-29     1    Trojan.Qhost-284              
comodo         15023          5.1               2014-09-22     3    TrojWare.Win32.Refroso.bj     
ctch           4.6.5          5.3.14            2013-12-01     1    Found nothing                 
drweb          5.0.2.3300     5.0.1.1           2014-09-28     29   Found nothing                 
fortinet                                                       1    Found nothing                 
fprot          4.6.2.117      6.5.1.5418        2014-09-30     1    Found nothing                 
fsecure        2014-04-02-01  9.13              2014-04-02     1    Found nothing                 
gdata          24.3819        24.3819           2014-08-29     7    Found nothing                 
hauri          2.73           2.73              2014-06-13     1    Found nothing                 
ikarus         1.06.01        V1.32.31.0        2014-09-30     13   Found nothing                 
jiangmin       16.0.100       1.0.0.0           2014-07-28     14   Found nothing                 
kaspersky      5.5.33         5.5.33            2014-04-01     19   Found nothing                 
kingsoft       2.1            2.1               2013-09-22     5    Found nothing                 
mcafee         7520           5400.1158         2014-08-04     8    Found nothing                 
nod32          0436           3.0.21            2014-09-18     1    Found nothing                 
panda          9.05.01        9.05.01           2014-06-15     3    Found nothing                 
pcc            11.182.06      9.500-1005        2014-09-30     1    Found nothing                 
qh360          1.0.1          1.0.1             1.0.1          12   Found nothing                 
qqphone        1.0.0.0        1.0.0.0           2014-10-01     1    Found nothing                 
quickheal      14.00          14.00             2014-06-14     2    Found nothing                 
rising         25.17.00.04    25.17.00.04       2014-06-02     4    Found nothing                 
sophos         5.04           3.51.0            2014-08-05     6    Found nothing                 
sunbelt        3.9.2589.2     3.9.2589.2        2014-06-13     1    Found nothing                 
symantec       20140929.001   1.3.0.24          2014-09-29     1    Found nothing                 
tachyon        9.9.9          9.9.9             2013-12-27     3    Found nothing                 
thehacker      6.8.0.5        6.8.0.5           2014-06-12     1    Found nothing                 
tws            17.47.17308    1.0.2.2108        2014-06-16     6    Suspicious:Heuri.NewThreat.MVM
vba            3.12.26.3      3.12.26.3         2014-09-30     3    Found nothing                 
virusbuster    15.0.924.0     5.5.2.13          2014-09-29     15   Found nothing                 


------------------------- END  ----------------------------------

